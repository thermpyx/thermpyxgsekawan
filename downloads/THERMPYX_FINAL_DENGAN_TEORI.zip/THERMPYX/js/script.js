/* =========================================================
   THERMPYX
   Thermodynamic Learning & Calculation Platform
   MAIN JAVASCRIPT
========================================================= */


/* =========================================================
   1. BASIC ELEMENTS
========================================================= */

const body = document.body;

const sidebar =
    document.getElementById("sidebar");

const sidebarToggle =
    document.getElementById("sidebarToggle");

const themeToggle =
    document.getElementById("themeToggle");

const mobileThemeToggle =
    document.getElementById("mobileThemeToggle");

const themeIcon =
    document.getElementById("themeIcon");

const themeText =
    document.getElementById("themeText");


/* =========================================================
   2. SIDEBAR
========================================================= */

const sidebarBackdrop = document.createElement("button");
sidebarBackdrop.className = "sidebar-backdrop";
sidebarBackdrop.type = "button";
sidebarBackdrop.hidden = !sidebar;
sidebarBackdrop.setAttribute("aria-label", "Close navigation");
sidebarBackdrop.tabIndex = -1;
document.body.append(sidebarBackdrop);
function syncSidebar() {
    const mobile = window.innerWidth <= 768;
    const open = mobile ? body.classList.contains("sidebar-mobile-open") : !body.classList.contains("sidebar-collapsed");
    sidebarToggle?.setAttribute("aria-expanded", String(open));
    sidebarToggle?.setAttribute("aria-controls", "sidebar");
    if (sidebar) sidebar.inert = mobile && !open;
    sidebarBackdrop.setAttribute("aria-hidden", String(!mobile || !open));
}
sidebarBackdrop.addEventListener("click", () => {body.classList.remove("sidebar-mobile-open");syncSidebar();sidebarToggle?.focus();});
document.addEventListener("keydown", event => {
    if (event.key === "Escape" && body.classList.contains("sidebar-mobile-open")) {
        body.classList.remove("sidebar-mobile-open");syncSidebar();sidebarToggle?.focus();
    }
});
if (sidebarToggle) {
    sidebarToggle.innerHTML = '<span class="menu-line"></span><span class="menu-line"></span><span class="menu-line"></span>';

    sidebarToggle.addEventListener(
        "click",
        function () {

            if (window.innerWidth > 768) {

                body.classList.toggle(
                    "sidebar-collapsed"
                );

            }
            else {

                body.classList.toggle(
                    "sidebar-mobile-open"
                );

            }
            syncSidebar();

        }
    );

}


/* =========================================================
   3. MOBILE NAVIGATION
========================================================= */

const navItems =
    document.querySelectorAll(".nav-item");


navItems.forEach(function (item) {

    item.addEventListener(
        "click",
        function () {

            if (window.innerWidth <= 768) {

                body.classList.remove(
                    "sidebar-mobile-open"
                );
                syncSidebar();

            }

        }
    );

});


/* =========================================================
   4. THEME SYSTEM
========================================================= */

function setTheme(theme) {

    if (theme === "light") {

        body.classList.add("light-mode");

        if (themeIcon) {

            themeIcon.textContent = "☀";

        }

        if (themeText) {

            themeText.textContent = "Light Mode";

        }

    }

    else {

        body.classList.remove("light-mode");

        if (themeIcon) {

            themeIcon.textContent = "☾";

        }

        if (themeText) {

            themeText.textContent = "Dark Mode";

        }

    }


    localStorage.setItem(
        "thermpyx-theme",
        theme
    );

}


/* =========================================================
   5. THEME BUTTON
========================================================= */

function toggleTheme() {

    if (
        body.classList.contains(
            "light-mode"
        )
    ) {

        setTheme("dark");

    }

    else {

        setTheme("light");

    }

}


if (themeToggle) {

    themeToggle.addEventListener(
        "click",
        toggleTheme
    );

}


if (mobileThemeToggle) {

    mobileThemeToggle.addEventListener(
        "click",
        toggleTheme
    );

}


/* =========================================================
   6. LOAD SAVED THEME
========================================================= */

const savedTheme =
    localStorage.getItem(
        "thermpyx-theme"
    );


if (savedTheme === "light") {

    setTheme("light");

}

else {

    setTheme("dark");

}


/* =========================================================
   7. ACTIVE NAVIGATION
========================================================= */

const sections =
    document.querySelectorAll(
        "main section[id]"
    );


function updateActiveNavigation() {

    if (!sections.length) {

        return;

    }


    let currentSection = "";

    const scrollPosition =
        window.scrollY + 120;


    sections.forEach(function (section) {

        const sectionTop =
            section.offsetTop;

        const sectionHeight =
            section.offsetHeight;


        if (
            scrollPosition >= sectionTop &&
            scrollPosition <
            sectionTop + sectionHeight
        ) {

            currentSection =
                section.id;

        }

    });


    // The final section may be shorter than the viewport and cannot reach the
    // normal topbar threshold. Keep its menu entry active at the page bottom.
    const pageHeight = document.documentElement.scrollHeight;
    if (pageHeight > window.innerHeight && window.scrollY + window.innerHeight >= pageHeight - 2) {
        const lastSection = Array.from(sections).reverse().find(section =>
            section.offsetHeight > 0 && Array.from(navItems).some(item =>
                item.getAttribute("href") === "#" + section.id
            )
        );
        if (lastSection) currentSection = lastSection.id;
    }

    navItems.forEach(function (item) {

        item.classList.remove("active");


        const link =
            item.getAttribute("href");


        if (
            link ===
            "#" + currentSection
        ) {

            item.classList.add("active");

        }

    });

}


window.addEventListener(
    "scroll",
    updateActiveNavigation
);


updateActiveNavigation();


/* =========================================================
   8. NAVIGATION CLICK
========================================================= */

navItems.forEach(function (item) {

    item.addEventListener(
        "click",
        function (event) {

            const targetId =
                item.getAttribute("href");


            if (
                !targetId ||
                !targetId.startsWith("#")
            ) {

                return;

            }


            const target =
                document.querySelector(
                    targetId
                );


            if (!target) {

                return;

            }


            event.preventDefault();


            const topbarHeight =
                window.innerWidth <= 768
                    ? 65
                    : 70;


            const targetPosition =
                target.getBoundingClientRect().top +
                window.scrollY -
                topbarHeight;


            window.scrollTo({

                top: targetPosition,

                behavior: "smooth"

            });

        }
    );

});


/* =========================================================
   9. HERO BUTTON NAVIGATION
========================================================= */

const heroLinks =
    document.querySelectorAll(
        '.primary-button, .secondary-button'
    );


heroLinks.forEach(function (link) {

    link.addEventListener(
        "click",
        function (event) {

            const targetId =
                link.getAttribute("href");


            if (
                !targetId ||
                !targetId.startsWith("#")
            ) {

                return;

            }


            const target =
                document.querySelector(
                    targetId
                );


            if (!target) {

                return;

            }


            event.preventDefault();


            const topbarHeight =
                window.innerWidth <= 768
                    ? 65
                    : 70;


            const targetPosition =
                target.getBoundingClientRect().top +
                window.scrollY -
                topbarHeight;


            window.scrollTo({

                top: targetPosition,

                behavior: "smooth"

            });

        }
    );

});


/* =========================================================
   10. CLOSE MOBILE SIDEBAR
========================================================= */

document.addEventListener(
    "click",
    function (event) {

        if (window.innerWidth > 768) {

            return;

        }


        if (
            !body.classList.contains(
                "sidebar-mobile-open"
            )
        ) {

            return;

        }


        const clickedInsideSidebar =
            sidebar &&
            sidebar.contains(event.target);


        const clickedToggle =
            sidebarToggle &&
            sidebarToggle.contains(event.target);


        if (
            !clickedInsideSidebar &&
            !clickedToggle
        ) {

            body.classList.remove(
                "sidebar-mobile-open"
            );
            syncSidebar();

        }

    }
);


/* =========================================================
   11. RESIZE
========================================================= */

window.addEventListener(
    "resize",
    function () {

        if (window.innerWidth > 768) {

            body.classList.remove(
                "sidebar-mobile-open"
            );

        }
        syncSidebar();

    }
);

syncSidebar();


/* =========================================================
   12. NUMBER FORMATTER
========================================================= */

function formatNumber(number) {

    return new Intl.NumberFormat(
        "en-US",
        {
            maximumFractionDigits: 6
        }
    ).format(number);

}


/* =========================================================
   13. HEAT CALCULATOR
   Formula:
   Q = m × c × ΔT
========================================================= */

const calculateHeatButton =
    document.getElementById(
        "calculateHeatButton"
    );

const heatMass =
    document.getElementById(
        "heatMass"
    );

const heatSpecificHeat =
    document.getElementById(
        "heatSpecificHeat"
    );

const heatTemperature =
    document.getElementById(
        "heatTemperature"
    );

const heatResult =
    document.getElementById(
        "heatResult"
    );

const heatResultValue =
    document.getElementById(
        "heatResultValue"
    );

const heatStep1 =
    document.getElementById(
        "heatStep1"
    );

const heatStep2 =
    document.getElementById(
        "heatStep2"
    );

const heatStep3 =
    document.getElementById(
        "heatStep3"
    );

const heatFinalAnswer =
    document.getElementById(
        "heatFinalAnswer"
    );


if (calculateHeatButton) {

    calculateHeatButton.addEventListener(
        "click",
        function () {

            const mass =
                Number(
                    heatMass.value
                );

            const specificHeat =
                Number(
                    heatSpecificHeat.value
                );

            const temperatureChange =
                Number(
                    heatTemperature.value
                );


            if (
                !Number.isFinite(mass) ||
                !Number.isFinite(
                    specificHeat
                ) ||
                !Number.isFinite(
                    temperatureChange
                )
            ) {

                alert(
                    "Please fill in all Heat Calculator fields."
                );

                return;

            }


            if (mass <= 0) {

                alert(
                    "Mass must be greater than 0."
                );

                heatMass.focus();

                return;

            }


            if (specificHeat <= 0) {

                alert(
                    "Specific heat capacity must be greater than 0."
                );

                heatSpecificHeat.focus();

                return;

            }


            const heat =
                mass *
                specificHeat *
                temperatureChange;


            const m =
                formatNumber(mass);

            const c =
                formatNumber(
                    specificHeat
                );

            const deltaT =
                formatNumber(
                    temperatureChange
                );

            const q =
                formatNumber(heat);


            heatResultValue.textContent =
                `Q = ${q} J`;


            heatStep1.textContent =
                "Q = m × c × ΔT";


            heatStep2.textContent =
                `Q = (${m}) × (${c}) × (${deltaT})`;


            heatStep3.textContent =
                `Q = ${q} J`;


            heatFinalAnswer.textContent =
                `Q = ${q} J`;


            heatResult.classList.add(
                "show"
            );


            saveCalculationHistory({

                type: "Heat",
                historyLabels: { titleEn: "Heat", titleId: "Kalor" },

                formula:
                    "Q = m × c × ΔT",

                inputs:
                    `m = ${m} kg | c = ${c} J/kg·K | ΔT = ${deltaT} K`,

                result:
                    `Q = ${q} J`

            });

        }
    );

}


/* =========================================================
   14. WORK CALCULATOR
   Formula:
   W = P × ΔV
========================================================= */

const calculateWorkButton =
    document.getElementById(
        "calculateWorkButton"
    );

const workPressure =
    document.getElementById(
        "workPressure"
    );

const workVolume =
    document.getElementById(
        "workVolume"
    );

const workResult =
    document.getElementById(
        "workResult"
    );

const workResultValue =
    document.getElementById(
        "workResultValue"
    );

const workStep1 =
    document.getElementById(
        "workStep1"
    );

const workStep2 =
    document.getElementById(
        "workStep2"
    );

const workStep3 =
    document.getElementById(
        "workStep3"
    );

const workFinalAnswer =
    document.getElementById(
        "workFinalAnswer"
    );


if (calculateWorkButton) {

    calculateWorkButton.addEventListener(
        "click",
        function () {

            const pressure =
                Number(
                    workPressure.value
                );

            const volumeChange =
                Number(
                    workVolume.value
                );


            if (
                !Number.isFinite(
                    pressure
                ) ||
                !Number.isFinite(
                    volumeChange
                )
            ) {

                alert(
                    "Please fill in all Work Calculator fields."
                );

                return;

            }


            const work =
                pressure *
                volumeChange;


            const p =
                formatNumber(
                    pressure
                );

            const deltaV =
                formatNumber(
                    volumeChange
                );

            const w =
                formatNumber(work);


            workResultValue.textContent =
                `W = ${w} J`;


            workStep1.textContent =
                "W = P × ΔV";


            workStep2.textContent =
                `W = (${p}) × (${deltaV})`;


            workStep3.textContent =
                `W = ${w} J`;


            workFinalAnswer.textContent =
                `W = ${w} J`;


            workResult.classList.add(
                "show"
            );


            saveCalculationHistory({

                type: "Work",
                historyLabels: { titleEn: "Work", titleId: "Usaha" },

                formula:
                    "W = P × ΔV",

                inputs:
                    `P = ${p} Pa | ΔV = ${deltaV} m³`,

                result:
                    `W = ${w} J`

            });

        }
    );

}


/* Temperature selection and conversion: temperature-converter.js. */

/* =========================================================
   16. PRESSURE CONVERTER
   Atmosphere ↔ Pascal
========================================================= */

function setupTwoWayConverter(config) {
    const fromDisplay = document.getElementById(config.fromDisplayId);
    const toDisplay = document.getElementById(config.toDisplayId);
    const direction = document.getElementById(config.directionId);
    const valueInput = document.getElementById(config.valueId);
    const swapButton = document.getElementById(config.swapId);
    const convertButton = document.getElementById(config.convertId);
    const resultDisplay = document.getElementById(config.resultId);

    if (!fromDisplay || !toDisplay || !direction || !valueInput || !swapButton || !convertButton || !resultDisplay) {
        return;
    }

    let reversed = false;

    function updateDirection() {
        const from = reversed ? config.to : config.from;
        const to = reversed ? config.from : config.to;
        fromDisplay.textContent = from.label;
        toDisplay.textContent = to.label;
        direction.textContent = `${from.short} → ${to.short}`;
        resultDisplay.textContent = "...";
    }

    swapButton.addEventListener("click", function () {
        reversed = !reversed;
        updateDirection();
    });

    convertButton.addEventListener("click", function () {
        const value = Number(valueInput.value);

        if (!Number.isFinite(value)) {
            alert(config.emptyMessage);
            valueInput.focus();
            return;
        }

        const result = reversed
            ? config.reverse(value)
            : config.forward(value);

        const target = reversed ? config.from : config.to;
        resultDisplay.textContent = `${formatNumber(result)} ${target.short}`;
    });

    updateDirection();
}

setupTwoWayConverter({
    fromDisplayId: "pressureFromDisplay",
    toDisplayId: "pressureToDisplay",
    directionId: "pressureDirection",
    valueId: "pressureConverterValue",
    swapId: "pressureSwapButton",
    convertId: "convertPressureButton",
    resultId: "pressureConversionValue",
    from: { label: "Atmosphere (atm)", short: "atm" },
    to: { label: "Pascal (Pa)", short: "Pa" },
    forward: value => value * 101325,
    reverse: value => value / 101325,
    emptyMessage: "Please enter a pressure value."
});

/* =========================================================
   17. VOLUME CONVERTER
   Liter ↔ Cubic Meter
========================================================= */

setupTwoWayConverter({
    fromDisplayId: "volumeFromDisplay",
    toDisplayId: "volumeToDisplay",
    directionId: "volumeDirection",
    valueId: "volumeConverterValue",
    swapId: "volumeSwapButton",
    convertId: "convertVolumeButton",
    resultId: "volumeConversionValue",
    from: { label: "Liter (L)", short: "L" },
    to: { label: "Cubic Meter (m³)", short: "m³" },
    forward: value => value / 1000,
    reverse: value => value * 1000,
    emptyMessage: "Please enter a volume value."
});


/* REV 08: Unified learning history. Keep existing calculator calls compatible. */
function saveCalculationHistory(calculation) {
  const caption = calculation?.type || "Calculation";
  const detail = [calculation?.formula, calculation?.result].filter(Boolean).join(" | ");
  if (window.TPXHistory) {
    window.TPXHistory.log("calculation", caption, detail, location.pathname+"#calculation", calculation?.historyLabels);
  } else {
    // Fallback if unified logger was blocked: do not lose a calculation.
    try {
      const list=JSON.parse(localStorage.getItem("thermpyx-history")||"[]");
      list.unshift({...calculation,time:new Date().toLocaleString()});
      localStorage.setItem("thermpyx-history",JSON.stringify(list.slice(0,50)));
    } catch (_) {}
  }
}
/* =========================================================
   21. INITIAL MESSAGE
========================================================= */

console.log(
    "THERMPYX initialized successfully."
);

console.log(
    "Sidebar system: ready."
);

console.log(
    "Theme system: ready."
);

console.log(
    "Navigation system: ready."
);

console.log(
    "Heat Calculator: ready."
);

console.log(
    "Work Calculator: ready."
);
console.log(
    "Temperature Converter: ready."
);
console.log(
    "History system: ready."
);
